package mypackage;

import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import org.json.simple.*;
import org.json.simple.parser.*;
public class CarRentalList extends HttpServlet {


  public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
    res.setContentType("text/html");
    PrintWriter out = res.getWriter();
    String nombre = req.getParameter("userid");
    String p = req.getParameter("password");
    if (nombre.trim().equals("admin") && p.trim().equals("123")){

    	out.println("<html><h1>Rental List:</h1><br></html>");
   	String path = "/home/ubuntu/Baixades/pti/servlets/apache-tomcat-10.0.10/JSONRentals/"; 
	File directory = new File(path);
	File[] jsonFiles = directory.listFiles((dir, name) -> name.endsWith(".json"));
        
	for (File jsonFile : jsonFiles) {
	
		JSONParser parser = new JSONParser();
		
		try (FileReader reader = new FileReader(jsonFile)) {
			
			JSONArray jsonArray = (JSONArray) parser.parse(reader);
			out.println("<html>CO2 Rating: " + jsonArray.get(0) + "<br>Engine: " + jsonArray.get(1) + "<br>Number of days: " + jsonArray.get(2) + "<br>Number of units: " + jsonArray.get(3) + "<br>Discount: " + jsonArray.get(4) + "<br><br></html>");
		
		} catch (IOException | ParseException e) { e.printStackTrace(); }
    	}
	out.println("<html><a href=carrental_home.html>Home</a></html>");
    }
    else out.println("Wrong Credentials >:/<html><br><br><html><a href=carrental_home.html>Home</a></html>");
  }

  public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
    doGet(req, res);
  }
}

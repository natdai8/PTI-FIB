package mypackage;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import java.io.FileWriter;
import java.io.IOException;
import java.io.*;
import java.util.Date;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.util.Random;
public class CarRentalNew extends HttpServlet {

  public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
    res.setContentType("text/html");
    String[] imageSources = {
    	"https://freepngimg.com/thumb/car/3-2-car-free-download-png.png",
	"https://freepngimg.com/thumb/car/4-2-car-png-hd.png",
	"https://freepngimg.com/thumb/car/1-2-car-png-picture.png",
	"https://freepngimg.com/thumb/audi/2-black-r8-audi-png-car-image.png",
	"https://freepngimg.com/thumb/car/7-2-car-free-png-image.png",
	"https://freepngimg.com/thumb/car/2-2-car-transparent.png",
	"https://freepngimg.com/thumb/lamborghini/1-2-lamborghini-png.png",
	"https://freepngimg.com/thumb/car/12-2-car-png-image.png",
	"https://freepngimg.com/thumb/car/6-2-car-png-file.png"
    };
    Random r = new Random();
    int i = r.nextInt(imageSources.length);
    String op = imageSources[i];
    PrintWriter out = res.getWriter();
    out.println("<html><h1>Your Rental Data: </h1><br></html>");
    int h = 250;
    int w = 400;
    out.println("<img src=\"" + op + "\" width=\"" + w + "\" height=\"" + h + "\">");
    String disc = req.getParameter("descompte");
    String num = req.getParameter("num_vehicles");
    String co2 = req.getParameter("co2_rating");
    String llog = req.getParameter("dies_lloguer");
    String mod = req.getParameter("sub_model_vehicle");
    out.println("<html><br><br>CO2 rating: " + co2 +"<br>Engine: " + mod +"<br>Number of days: " + llog + "<br>Number of units: " + num + "<br>Discount: " + disc + "<html><br><br><a href=carrental_home.html>Home</a></html>");

    JSONObject rentals = new JSONObject();
    rentals.put("Name", "Rentals");
    JSONArray j = new JSONArray();
    j.add(co2);
    j.add(mod);
    j.add(llog);
    j.add(num);
    j.add(disc);
    rentals.put("Data: ", j);
    Date now = new Date();
    String path = ("JSONRentals/" + now  + ".json");
    try (FileWriter file = new FileWriter(path)){
	file.write(j.toJSONString());
    } catch (IOException e) { e.printStackTrace(); }
  }

  public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
    doGet(req, res);
  }
}

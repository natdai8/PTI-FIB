const express = require('express')
const  fs = require('fs')
const app = express()
const port = 8080
const {DateTime} = require('luxon')
const path = require('path')

app.get('/', (req, res) => {
  res.send('Hello World!')
})

app.use(express.json());

app.post('/newstudent', (req, res, next) => {
    for(var i in req.body.students){
        console.log(req.body.students[i].name+'\n');
    	console.log(req.body.students[i].studentId+'\n');
    }
    res.status(201);
    res.end(); 
}) 

app.get("/students", (req, res, next) => {
    res.json({
        responseId: 1234,
        students: [
            {name: "Jordi", studentId: '12345678a'},
            {name: "Marta", studentId: '12345678b'}
    ]});
})

app.get("/request", (req, res) => {
	const dir = path.join(__dirname, 'Rentals');
	fs.readdir(dir, (err, files) => {
		if (err) {
			console.error(err);
			res.status(500)
			return
		}

		const rentals = files.filter(file => file.endsWith('.json'))
		const data = [];

		rentals.forEach(file => {
			const p = path.join(dir, file);
			const temp = fs.readFileSync(p)
			data.push(JSON.parse(temp));
		})
	res.json(data);
	})
})

app.post("/rent", (req, res) => {
	const data = req.body;
	const dataj = JSON.stringify(data);
	const date = DateTime.local().toFormat('yyyyMMddHHmmss');
	fs.writeFile(`Rentals/NewRent_${date}.json`, dataj, err => {
	  if (err) {
		console.error(err)
		res.status(500)
	  } else {
		console.log('Data written succesfully')
		res.status(201)
	  }
	  res.end()
	});
});

app.listen(port, () => {
  console.log(`PTI HTTP Server listening at http://localhost:${port}`)
})
